<?php 
	get_header();
?>
	<?php 
		$query = array(
		    "cat" => 3,
		    "posts_per_page" => 3,
		    "orderby" => "title",
		    "order" => "ASC"
		);
	?>
		<?php
			$cat = new WP_Query($query);
			if( $cat->have_posts() ){
			    while( $cat->have_posts() ){
			        ?>
			        <?php
				        $cat->the_post();
				        ?>	
						<div class="flex-container-posts">
					        <div class="container-image-post-header">    
					        	<?php the_post_thumbnail('cat');?>	
							  	<div class="overlay">
							    	<div class="text-title"><?php the_title(); ?></div>
							  	</div>
							</div>
							<div class="excerpt-posts">
								<div><?php the_excerpt(); ?></div>
							</div>
						</div>
			        <?php
			    }
			}			
		?>
<?php			
	get_footer();
?>